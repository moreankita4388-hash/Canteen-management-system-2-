CANTEEN MANAGEMENT SYSTEM - C WEBSITE PROJECT

Files:
- index.html : Website frontend
- canteen.c  : C CGI backend

Requirements:
- Apache web server with CGI enabled
- GCC compiler
- Linux/Apache CGI environment

Basic setup:
1. Place index.html in the web server document root.
2. Compile canteen.c using:
   gcc canteen.c -o canteen.cgi
3. Put canteen.cgi in the server's cgi-bin directory.
4. Enable CGI in Apache and restart the server.
5. Ensure the CGI program can write orders.txt in its working directory.
6. Open http://localhost/index.html

Note:
This is an educational starter project. The admin orders page has no login protection.
Do not publish it on the internet without adding authentication and security.

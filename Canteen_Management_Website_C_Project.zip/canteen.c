#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILE_NAME "orders.txt"

void print_header(const char *title) {
    printf("Content-Type: text/html\r\n\r\n");
    printf("<!DOCTYPE html><html><head><title>%s</title>", title);
    printf("<meta name='viewport' content='width=device-width, initial-scale=1'>");
    printf("<style>");
    printf("body{font-family:Arial;background:#f4f6f8;margin:0;padding:25px;color:#222}");
    printf(".card{max-width:700px;margin:25px auto;background:white;padding:25px;border-radius:12px;box-shadow:0 2px 12px #ccc}");
    printf("h1{color:#174a7e;text-align:center} table{width:100%%;border-collapse:collapse}");
    printf("td,th{padding:10px;border:1px solid #ddd;text-align:left}");
    printf("input,select{padding:10px;width:100%%;box-sizing:border-box;margin:8px 0 15px}");
    printf("button{background:#1769aa;color:white;border:0;padding:12px 20px;border-radius:6px;cursor:pointer}");
    printf("a{color:#1769aa} .price{font-weight:bold;color:#087443}");
    printf("</style></head><body><div class='card'>");
}

void show_home(void) {
    print_header("Canteen Management System");
    printf("<h1>Canteen Management System</h1>");
    printf("<p>Choose a food item, enter quantity and place your order.</p>");
    printf("<form method='POST' action='/cgi-bin/canteen.cgi'>");
    printf("<label>Food item</label><select name='item' required>");
    printf("<option value='Tea'>Tea - Rs. 10</option>");
    printf("<option value='Coffee'>Coffee - Rs. 20</option>");
    printf("<option value='Poha'>Poha - Rs. 25</option>");
    printf("<option value='Sandwich'>Sandwich - Rs. 40</option>");
    printf("<option value='Vadapav'>Vadapav - Rs. 20</option>");
    printf("<option value='Misal'>Misal - Rs. 50</option>");
    printf("</select>");
    printf("<label>Quantity</label><input type='number' name='qty' min='1' max='50' value='1' required>");
    printf("<button type='submit'>Place Order</button></form>");
    printf("<hr><p><a href='/cgi-bin/canteen.cgi?action=view'>View all orders (Admin)</a></p>");
    printf("</div></body></html>");
}

int price_of(const char *item) {
    if (strcmp(item,"Tea")==0) return 10;
    if (strcmp(item,"Coffee")==0) return 20;
    if (strcmp(item,"Poha")==0) return 25;
    if (strcmp(item,"Sandwich")==0) return 40;
    if (strcmp(item,"Vadapav")==0) return 20;
    if (strcmp(item,"Misal")==0) return 50;
    return 0;
}

/* Read a URL-encoded form field. This starter project uses simple field values. */
void get_field(const char *data, const char *key, char *out, size_t out_size) {
    char pattern[40];
    snprintf(pattern, sizeof(pattern), "%s=", key);
    const char *p = strstr(data, pattern);
    if (!p) { out[0] = '\0'; return; }
    p += strlen(pattern);
    size_t i = 0;
    while (*p && *p != '&' && i + 1 < out_size) {
        if (*p == '+') out[i++] = ' ';
        else if (*p == '%' && p[1] && p[2]) {
            char hex[3] = {p[1], p[2], '\0'};
            out[i++] = (char)strtol(hex, NULL, 16);
            p += 2;
        } else out[i++] = *p;
        p++;
    }
    out[i] = '\0';
}

void place_order(void) {
    char *length_text = getenv("CONTENT_LENGTH");
    int length = length_text ? atoi(length_text) : 0;
    if (length < 0 || length > 10000) length = 0;

    char data[10001] = {0};
    if (length > 0) fread(data, 1, (size_t)length, stdin);

    char item[50], qty_text[20];
    get_field(data, "item", item, sizeof(item));
    get_field(data, "qty", qty_text, sizeof(qty_text));

    int qty = atoi(qty_text);
    int price = price_of(item);

    print_header("Order Confirmation");
    if (price == 0 || qty < 1 || qty > 50) {
        printf("<h1>Invalid order</h1><p>Please select a valid item and quantity.</p>");
    } else {
        int total = price * qty;
        FILE *fp = fopen(FILE_NAME, "a");
        if (fp) {
            fprintf(fp, "%s,%d,%d,%d\n", item, qty, price, total);
            fclose(fp);
            printf("<h1>Order placed successfully!</h1>");
            printf("<p>Item: <b>%s</b></p><p>Quantity: %d</p>", item, qty);
            printf("<p>Price: Rs. %d</p><p class='price'>Total: Rs. %d</p>", price, total);
        } else {
            printf("<h1>Could not save order</h1><p>Check write permission for the CGI folder.</p>");
        }
    }
    printf("<p><a href='/index.html'>Back to menu</a> | ");
    printf("<a href='/cgi-bin/canteen.cgi?action=view'>View orders</a></p>");
    printf("</div></body></html>");
}

void view_orders(void) {
    print_header("Admin - Orders");
    printf("<h1>All Canteen Orders</h1><table>");
    printf("<tr><th>Food</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr>");
    FILE *fp = fopen(FILE_NAME, "r");
    char item[50];
    int qty, price, total, grand_total = 0, found = 0;
    if (fp) {
        while (fscanf(fp, "%49[^,],%d,%d,%d\n", item, &qty, &price, &total) == 4) {
            printf("<tr><td>%s</td><td>%d</td><td>Rs. %d</td><td>Rs. %d</td></tr>",
                   item, qty, price, total);
            grand_total += total;
            found = 1;
        }
        fclose(fp);
    }
    if (!found) printf("<tr><td colspan='4'>No orders yet.</td></tr>");
    printf("</table><h3>Grand Total: Rs. %d</h3>", grand_total);
    printf("<p><a href='/index.html'>Back to menu</a></p>");
    printf("</div></body></html>");
}

int main(void) {
    char *method = getenv("REQUEST_METHOD");
    char *query = getenv("QUERY_STRING");

    if (method && strcmp(method, "POST") == 0) {
        place_order();
    } else if (query && strstr(query, "action=view")) {
        view_orders();
    } else {
        show_home();
    }
    return 0;
}